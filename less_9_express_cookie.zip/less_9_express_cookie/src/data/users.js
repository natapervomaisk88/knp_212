export const users = [
  {
    id: 1,
    login: "vasya",
    password: "$2b$10$4E8QaGNP6lCgHtF5JIQLQu2lNO9leeyHIe/fxEgqdw38JlVgsADv2",
  },
];
