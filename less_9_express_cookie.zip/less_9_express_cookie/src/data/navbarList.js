export const navbarList = [
  { link: "/", title: "Home" },
  { link: "/user/signup", title: "Register" },
  { link: "/user/signin", title: "Auth" },
];
